1. To build the library, use a command line interface such as Terminal or Command Prompt to go the src directory and type in "fsharpc -a roguelike.fs"
2. To reference the library type in "fsharpc -r roguelike.dll roguelike-game.fsx"
3. To start the game type in "mono roguelike-game.exe"
4. Play the game and enjoy 